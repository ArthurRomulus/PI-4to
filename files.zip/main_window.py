from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel, QMessageBox
)
from PyQt5.QtCore import Qt

from ui.verify_window import VerifyWindow, AccessDeniedWindow
from ui.register_window import RegisterWindow
from ui.admin_dialog import AdminDialog


class MainWindow(QMainWindow):
    def __init__(self, access_controller):
        super().__init__()
        self.access_controller = access_controller
        self.setWindowTitle("Sistema de Control de Acceso")
        self.setMinimumSize(800, 480)
        self.setStyleSheet("""
            QWidget {
                background-color: #0f172a;
                color: #f1f5f9;
                font-family: 'Segoe UI';
                font-size: 16px;
            }
            QLabel#titleLabel {
                font-size: 28px;
                font-weight: bold;
                color: #38bdf8;
                padding: 20px;
            }
            QPushButton {
                background-color: #1e293b;
                border: 2px solid #38bdf8;
                border-radius: 10px;
                padding: 15px;
                font-size: 18px;
            }
            QPushButton:hover { background-color: #38bdf8; color: #0f172a; }
            QPushButton:pressed { background-color: #0ea5e9; }
        """)
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()
        layout.setSpacing(30)
        layout.setAlignment(Qt.AlignCenter)

        title = QLabel("CONTROL DE ACCESO BIOMÉTRICO")
        title.setAlignment(Qt.AlignCenter)
        title.setObjectName("titleLabel")

        btn_verify = QPushButton("VERIFICAR IDENTIDAD")
        btn_verify.setFixedHeight(70)
        btn_verify.clicked.connect(self.open_verify)

        btn_register = QPushButton("REGISTRAR USUARIO")
        btn_register.setFixedHeight(70)
        btn_register.clicked.connect(self.open_register)

        btn_denied = QPushButton("SIMULAR ACCESO DENEGADO")
        btn_denied.setFixedHeight(50)
        btn_denied.clicked.connect(self.open_denied)

        btn_exit = QPushButton("SALIR")
        btn_exit.setFixedHeight(50)
        btn_exit.clicked.connect(self.close_system)

        layout.addWidget(title)
        layout.addWidget(btn_verify)
        layout.addWidget(btn_register)
        layout.addWidget(btn_denied)
        layout.addWidget(btn_exit)
        central_widget.setLayout(layout)

    def open_verify(self):
        self.verify_window = VerifyWindow(self.access_controller)
        self.verify_window.show()

    def open_register(self):
        dialog = AdminDialog(self.access_controller)
        if dialog.exec_():
            self.register_window = RegisterWindow(self.access_controller)
            self.register_window.show()

    def open_denied(self):
        self.denied_window = AccessDeniedWindow()
        self.denied_window.show()

    def close_system(self):
        confirm = QMessageBox.question(
            self, "Confirmar", "¿Desea cerrar el sistema?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm == QMessageBox.Yes:
            self.close()
